# Reading Quiz Battle

## Important
This package is a classroom-ready FRONTEND prototype. It contains:
- Host / Join screens
- Room code
- QR code for the room
- 50-player limit in the UI
- Short reading passages
- 20-second timer
- Multiple-choice questions
- Speed bonus points
- Leaderboard
- Final results

## Upload
You can upload the files to GitHub Pages or Netlify.

### Netlify
1. Put all files in one folder.
2. Drag the folder into Netlify Drop, or connect the GitHub repository.
3. Open the generated site URL.
4. Teacher opens the site and chooses Host.
5. Students scan the QR code.

## Important multiplayer note
A truly synchronized 50-player game requires a realtime backend such as Firebase Realtime Database or Supabase Realtime. This package deliberately keeps the frontend simple so it can be deployed immediately. For a real classroom with all 50 students sharing the same state, the next step is to connect `players`, room state, current question, answers, and scores to Firebase/Supabase.

## Files
- index.html
- style.css
- app.js
- README.md
