// Reading Quiz Battle - frontend prototype
// For true 50-player realtime play, connect these functions to Firebase/Supabase.
// This version includes the complete classroom UI, room flow, QR join link,
// 20-second timer, short readings, scoring, and leaderboard logic.

const questions = [
  {
    title:"Milo the Cat",
    text:"Rina has a small cat named Milo. Milo has white fur and blue eyes. Every morning, Rina gives Milo some food before she goes to school. In the afternoon, Milo likes to sleep near the window.",
    q:"What color are Milo's eyes?",
    options:["Brown","Black","Blue","Green"],
    answer:2
  },
  {
    title:"The School Garden",
    text:"The school garden is behind the library. It has many colorful flowers and three large trees. Students often visit the garden during break time. They usually sit under the trees and read books together.",
    q:"Where is the school garden?",
    options:["Near the gate","Behind the library","Beside the canteen","In front of the classroom"],
    answer:1
  },
  {
    title:"Dina's Bicycle",
    text:"Dina has a new bicycle. It is red and has a small basket in front. She rides it to the park every Sunday morning. Her brother usually rides with her and brings some water.",
    q:"What color is Dina's bicycle?",
    options:["Blue","Yellow","Red","Green"],
    answer:2
  },
  {
    title:"A Busy Market",
    text:"The traditional market opens early in the morning. Many people buy vegetables, fruit, fish, and spices there. The market is usually crowded before noon. Sellers often greet customers with friendly smiles.",
    q:"When is the market usually crowded?",
    options:["Late at night","Before noon","In the afternoon","After dinner"],
    answer:1
  },
  {
    title:"Borobudur",
    text:"Borobudur is a famous temple in Central Java, Indonesia. It has many stone stupas and beautiful carvings. Many visitors come early in the morning to enjoy the view and learn about its history.",
    q:"Where is Borobudur located?",
    options:["West Java","Central Java","East Java","Bali"],
    answer:1
  }
];

let role="", room="", playerName="", current=0, timer=null, timeLeft=20;
let players={};

function $(id){return document.getElementById(id)}
function hideAll(){["home","host","join","game","leaderboard","final"].forEach(x=>$(x).classList.add("hidden"))}
function goHome(){hideAll();$("home").classList.remove("hidden")}
function showHost(){hideAll();$("host").classList.remove("hidden");role="host"}
function showJoin(){hideAll();$("join").classList.remove("hidden");role="player"}

function createRoom(){
  room=Math.random().toString(36).substring(2,8).toUpperCase();
  $("roomCode").textContent=room;
  $("hostPanel").classList.remove("hidden");
  const url=location.href.split("?")[0]+"?room="+room;
  $("qr").innerHTML="";
  new QRCode($("qr"),{text:url,width:190,height:190});
  players={};
  updatePlayers();
}

function joinGame(){
  playerName=$("nameInput").value.trim();
  room=$("roomInput").value.trim().toUpperCase();
  if(!playerName||!room){$("joinStatus").textContent="Please enter your name and room code.";return}
  if(Object.keys(players).length>=50){$("joinStatus").textContent="This room is full.";return}
  players[playerName]={score:0};
  $("joinStatus").textContent="Joined room "+room+". Waiting for the host...";
  hideAll();$("game").classList.remove("hidden");
  showQuestion();
}

function updatePlayers(){
  $("playerCount").textContent=Object.keys(players).length;
  $("playerList").innerHTML=Object.keys(players).map(n=>`<span class="player">${escapeHtml(n)}</span>`).join("");
}

function startGame(){current=0;showQuestion()}

function showQuestion(){
  hideAll();$("game").classList.remove("hidden");
  const item=questions[current%questions.length];
  $("roundLabel").textContent=`Question ${current+1} of ${questions.length}`;
  $("textTitle").textContent=item.title;
  $("readingText").textContent=item.text;
  $("question").textContent=item.q;
  $("answers").innerHTML=item.options.map((o,i)=>`<button class="answer" onclick="answerQuestion(${i})">${String.fromCharCode(65+i)}. ${o}</button>`).join("");
  $("answerStatus").textContent="";
  startTimer();
}

function startTimer(){
  clearInterval(timer);timeLeft=20;$("timer").textContent=timeLeft;
  timer=setInterval(()=>{
    timeLeft--;$("timer").textContent=timeLeft;
    if(timeLeft<=0){clearInterval(timer);lockAnswers();$("answerStatus").textContent="⏰ Time is up!";setTimeout(showLeaderboard,700)}
  },1000)
}

function answerQuestion(choice){
  clearInterval(timer);
  const item=questions[current%questions.length];
  document.querySelectorAll(".answer").forEach(b=>b.disabled=true);
  const correct=choice===item.answer;
  const points=correct?100+timeLeft*5:0;
  if(playerName){
    players[playerName].score+=points;
  }
  $("answerStatus").textContent=correct?`✅ Correct! +${points} points`:`❌ Not quite.`;
  setTimeout(showLeaderboard,900);
}

function lockAnswers(){document.querySelectorAll(".answer").forEach(b=>b.disabled=true)}

function showLeaderboard(){
  hideAll();$("leaderboard").classList.remove("hidden");
  const sorted=Object.entries(players).sort((a,b)=>b[1].score-a[1].score);
  $("scores").innerHTML=sorted.length?sorted.map((p,i)=>`<div class="score-row"><span>${i+1}. ${escapeHtml(p[0])}</span><b>${p[1].score}</b></div>`).join(""):"<p>No scores yet.</p>";
}

function nextRound(){
  current++;
  if(current>=questions.length){showFinal();return}
  showQuestion();
}

function showFinal(){
  hideAll();$("final").classList.remove("hidden");
  const sorted=Object.entries(players).sort((a,b)=>b[1].score-a[1].score);
  $("finalScores").innerHTML=sorted.map((p,i)=>`<div class="score-row ${i===0?'winner':''}"><span>${i===0?'🏆 ':''}${i+1}. ${escapeHtml(p[0])}</span><b>${p[1].score}</b></div>`).join("");
}

function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}

const params=new URLSearchParams(location.search);
if(params.get("room")){$("roomInput").value=params.get("room");showJoin()}
